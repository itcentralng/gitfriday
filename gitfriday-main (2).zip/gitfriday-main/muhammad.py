remark= "Alhamdulilah today is friday"
prayers='may our lives should be at peace in this world and here after Ameen'
l="jummat kareem" 