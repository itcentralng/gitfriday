name = "Al-Ameen Bature" 

if name == "Al-Ameen Bature":
    print("Original detected 😀")
else:
    print("Photocopy detected 😪")
